SELECT IsAnomaly, AnomalyScore, AlertMessage
FROM AnomalyFlags
WHERE Id = 1